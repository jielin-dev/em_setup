The `use-package' declaration macro allows you to isolate package
configuration in your ".emacs" in a way that is performance-oriented and,
well, just tidy.  I created it because I have over 80 packages that I use
in Emacs, and things were getting difficult to manage.  Yet with this
utility my total load time is just under 1 second, with no loss of
functionality!

Please see README.md from the same repository for documentation.
