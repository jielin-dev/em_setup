Projects using CMake do not integrate well into the Emacs ecosystem
which often assumes the existence of Makefiles.  This library
improves that situation somewhat.
